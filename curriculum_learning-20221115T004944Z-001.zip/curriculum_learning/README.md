# Curriculum learning

## Train
To train model on specific dataset, run `sh train.sh`. Indices of data set are stored in directory "datasets", which will be leveraged to pick specific images from Cifar.

In "train.sh", "train()" function is defined as example to train with a specific indices, and "train_with_random_sel()" function is defined as example to train with indices of random select. "train_with_level" refers to an example to train a model with several datasets (e.g. first train model with good dataset and then train the model with bad dataset).

## Evaluation
To test model, run `sh test.sh`. Function "test_with_sel()" and "test_with_sel_good()" are examples to test accuracy of model on specific dataset. To pick good and bad data subset from entire dataset, set "test_mode" to be "find" as shown in function "test_and_find()" and "test_and_find_eval()".

## Datasets
Datasets can be downloaded from [google drive](https://drive.google.com/drive/folders/10TlU8MuoxL9Nw_h3VLmPBIj4whxyL0VS?usp=sharing). Put the datasets under "curriculum_learning/datasets".