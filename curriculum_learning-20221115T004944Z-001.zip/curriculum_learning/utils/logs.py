import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]

import os
import torch
import torch.nn as nn
import numpy as np
from tensorboard_logger import configure, log_value
from scipy.misc import imsave

# from model.autoencoder import Resnet_AutoEncoder
from model.autoencoder_2 import Resnet_AutoEncoder
from model.getcls import get_cls
from utils.optim import get_optim

import pdb

# manage logs and file operation
class Logs:
    def __init__(self, opt):
        self.opt = opt
        # for file operiation
        self.save_root = opt.save_root
        self.save_file = os.path.join(opt.save_root, opt.save_file)
        self.load_file = os.path.join(opt.save_root, opt.model_file)
        self.tfboard_dir = os.path.join(opt.save_root, opt.tfboard_dir)
        self.load_pretrain = opt.load_pretrain
        self.save_epoch = opt.save_epoch
        # for model
        self.cls_num = opt.class_num
        self.model_mode = opt.model
        # for train
        self.lr = opt.lr
        self.optim = opt.optim
        self.no_gpu = opt.no_gpu
        # define tensorboard
        configure(self.tfboard_dir, flush_secs=5)

    # save current result
    def save_results(self, model, optim, epoch):
        save_dict = {'model':None, 'optim':None, 'epoch':None, 'optim_type':self.optim}
        try:
            save_dict['model'] = model.module.state_dict()
        except:
            save_dict['model'] = model.state_dict()
        save_dict['optim'] = optim.state_dict()
        save_dict['epoch'] = epoch

        torch.save(save_dict, self.save_file)

        if epoch != 0 and epoch % self.save_epoch == 0:
            epoch_file = '{}_epoch.pth'.format(epoch)
            torch.save(save_dict, os.path.join(self.save_root, epoch_file))

    # get weight from autoencoder
    def get_weight_from_auto(self, weight):
        print('loading from autoencoder')
        clean_weight = {}
        for key in weight:
            key_split = key.split('.')
            if key_split[0] != 'encoder':
                continue
            # head layer
            if key_split[1] == '0':
                clean_key = 'conv1.'+key_split[-1]
            elif key_split[1] == '1':
                clean_key = 'bn1.'+key_split[-1]
            # other layer
            else:
                clean_key = ['layer{}'.format(int(key_split[1])-3)] + key_split[2:]
                clean_key = '.'.join(clean_key)
            # load parameter
            clean_weight[clean_key] = weight[key]
        
        return clean_weight

    # load weight for model
    def load_weight(self, w_dict, model):
        model_weight = model.state_dict()
        # get exists
        mismatch_w = []
        for weight in w_dict:
            if weight in model_weight:
                model_weight[weight] = w_dict[weight]
            else:
                mismatch_w.append(weight)
        # get miss weight
        miss_w = []
        for key in model_weight:
            if key not in w_dict:
                miss_w.append(key)
        # load and print
        model.load_state_dict(model_weight)
        print('loading weight')
        if len(mismatch_w) > 0:
            print('mismatch weights: {}'.format(mismatch_w))
        if len(miss_w) > 0:
            print('miss weights: {}'.format(miss_w))

        return model

    # create model and optim
    def define_model(self):
        epoch = 0
        model = get_cls(cls_num=self.cls_num, model=self.model_mode)
        if self.load_pretrain and os.path.exists(self.load_file):
            print('load weight from {}'.format(self.load_file))
            save_dict = torch.load(self.load_file)
            # load from autoencoder pretrain
            if self.opt.load_from_auto:
                print('loading from autoencoder')
                save_weight = self.get_weight_from_auto(save_dict['model'])
            else:
                save_weight = save_dict['model']
            self.load_weight(save_weight, model)
            epoch = save_dict['epoch']
        # for optimizer
        if not self.no_gpu:
            model = nn.DataParallel(model).cuda()
        optim = get_optim(model, epoch=epoch, lr=self.lr, opt_fun=self.optim)
        if self.opt.only_weight:
            epoch = 0
            return model, optim, epoch
        # load optimizer
        if self.load_pretrain and os.path.exists(self.load_file):
            if self.optim == save_dict['optim_type']:
                optim.load_state_dict(save_dict['optim'])

        return model, optim, epoch

    # create autoencoder and optim
    def define_autoencoder(self):
        epoch = 0
        model = Resnet_AutoEncoder(model_type=self.model_mode)
        if self.load_pretrain and os.path.exists(self.load_file):
            save_dict = torch.load(self.load_file)
            model.load_state_dict(save_dict['model'])
            epoch = save_dict['epoch']
        # for optimizer
        if not self.no_gpu:
            model = nn.DataParallel(model).cuda()
        optim = get_optim(model, epoch=epoch, lr=self.lr, opt_fun=self.optim)
        if self.load_pretrain and os.path.exists(self.load_file):
            if self.optim == save_dict['optim_type']:
                optim.load_state_dict(save_dict['optim'])

        return model, optim, epoch

    # display results
    def display_results(self, epoch, results, optim):
        lr = optim.param_groups[0]['lr']
        accs = [pred==label for pred, label in zip(results['preds'], results['labels'])]
        accuracy = np.mean(np.concatenate(accs, axis=0))
        loss = np.mean(results['losses'])
        log_value('accuracy', accuracy, epoch)
        log_value('loss', loss, epoch)
        print('\n\n accuracy:{}, loss:{}, lr:{}'.format(accuracy, loss, lr))

    # display autoencoder results
    def display_autoencoder_results(self, epoch, results, optim):
        lr = optim.param_groups[0]['lr']
        test_loss = np.mean(results['test_loss'])
        train_loss = np.mean(results['losses'], axis=0)
        log_value('test_loss', test_loss, epoch)
        log_value('train_loss', train_loss, epoch)
        print('\n\n train_loss:{}, test_loss:{}, lr:{}'.format(train_loss, test_loss, lr))
        # save images
        image_dir = os.path.join(self.save_root, 'images')
        if not os.path.exists(image_dir):
            os.makedirs(image_dir)
        if epoch != 0 and epoch % self.save_epoch == 0:
            image_train_file = 'epoch_train_{}.png'.format(epoch)
            image_test_file = 'epoch_test_{}.png'.format(epoch)
            # get images
            train_images = np.hstack([np.vstack(imgs) for imgs in results['train_display']])
            test_images = np.hstack([np.vstack(imgs) for imgs in results['test_display']])
            # save
            imsave(os.path.join(image_dir, image_train_file), train_images)
            imsave(os.path.join(image_dir, image_test_file), test_images)