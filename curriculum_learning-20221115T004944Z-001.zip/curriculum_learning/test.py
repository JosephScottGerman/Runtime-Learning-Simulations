import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]
if '/home/cxu-serve/u1/gcui2/code/distillation' not in sys.path:
    sys.path.insert(0, '/home/cxu-serve/u1/gcui2/code/distillation')

from dataloader.cifar_loader import CifarLoader
from dataloader.define_loader import sel_loader, combine_loader
from option.base_option import get_parser
from model.getcls import get_cls
from model.autoencoder import Resnet_AutoEncoder

import os
import numpy as np
import torch
import torch.utils.data as Data
from tqdm import tqdm
from PIL import Image
from scipy.misc import imsave
import random

from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

import pdb

def test(opt):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # define model
    model = get_cls(cls_num=opt.class_num, model=opt.model)
    load_file = os.path.join(opt.save_root, opt.model_file)
    save_dict = torch.load(load_file)
    model.load_state_dict(save_dict['model'])
    if not opt.no_gpu:
        model = model.cuda()

    # evaluation
    results = {'preds':[], 'labels':[]}
    model.eval()
    with torch.no_grad():
        for data in tqdm(test_loader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            preds = torch.argmax(logits, dim=1)
            
            # store
            results['preds'].append(preds.data.cpu().numpy())
            results['labels'].append(labels.data.cpu().numpy())

        # display results
        accs = [pred==label for pred, label in zip(results['preds'], results['labels'])]
        accuracy = np.mean(np.concatenate(accs, axis=0))
        print('accuracy:{}'.format(accuracy))

def find_specific(opt, save_bool=True):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=opt.find_from_train)
    if opt.sel_test_file is not None:
        test_dataset = sel_loader(test_dataset, opt.sel_test_file, opt.sel_num)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False, drop_last=True)

    # define model
    model = get_cls(cls_num=opt.class_num, model=opt.model)
    load_file = os.path.join(opt.save_root, opt.model_file)
    save_dict = torch.load(load_file)
    model.load_state_dict(save_dict['model'])
    if not opt.no_gpu:
        model = model.cuda()

    # define loss
    loss_fun = torch.nn.CrossEntropyLoss(reduce=False)

    # test and store loss
    loss_store = {}
    with torch.no_grad():
        for data_id, data in enumerate(tqdm(test_loader)):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            loss = loss_fun(logits, labels)
            cur_index = data_id * opt.batch_size
            for label, score in zip(labels, loss):
                cur_label = label.detach().cpu().item()
                if cur_label not in loss_store:
                    loss_store[cur_label] = [[], []]
                loss_store[cur_label][0].append(score.detach().cpu().item())
                loss_store[cur_label][1].append(test_dataset.get_sel_ids(cur_index))
                cur_index += 1

    # get bad and good indices
    # sort_ids = np.argsort(loss_store)
    # good_indices = sort_ids[:1000]
    # bad_indices = sort_ids[-1000:]
    # test_indices = sort_ids[1000:-1000]
    good_indices = []
    bad_indices = []
    # test_indices = []
    level_indices_1 = []
    # level_indices_2 = []
    for label in loss_store:
        sort_ids = np.argsort(loss_store[label][0])
        total_len = sort_ids.shape[0]
        good_indices += np.asarray(loss_store[label][1])[sort_ids[0:75]].tolist()
        bad_indices += np.asarray(loss_store[label][1])[sort_ids[-75:]].tolist()
        # test_indices += np.asarray(loss_store[label][1])[sort_ids[100:-100]].tolist()
        # level_indices_1 += np.asarray(loss_store[label][1])[sort_ids[:50]].tolist() + \
        #                 np.asarray(loss_store[label][1])[sort_ids[-100:-50]].tolist()
        # level_indices_2 += np.asarray(loss_store[label][1])[sort_ids[:75]].tolist() + \
        #                 np.asarray(loss_store[label][1])[sort_ids[-(2*total_len//3):-(2*total_len//3-75)]].tolist()

    # store
    if save_bool:
        np.save(opt.find_store.format('good'), good_indices)
        np.save(opt.find_store.format('bad'), bad_indices)
        # np.save(opt.find_store.format('level'), level_indices_1)
        # np.save(opt.find_store.format('level2'), level_indices_2)
        # if not opt.find_from_train:
        #     np.save(opt.find_store.format('test'), test_indices)

    # return good_indices, bad_indices, test_indices
    return good_indices, bad_indices

def find_fix_test(opt):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_loader = Data.DataLoader(test_dataset, batch_size=1, num_workers=opt.num_worker, shuffle=False, drop_last=True)
    
    # test and store loss
    item_store = {}
    with torch.no_grad():
        for data_id, data in enumerate(tqdm(test_loader)):
            # set to gpu
            labels = data[0].item()
            # store
            if labels not in item_store:
                item_store[labels] = []
            item_store[labels].append(data_id)

    test_indices = []
    train_indices = []
    # randomly select
    for label in item_store:
        np.random.shuffle(item_store[label])
        test_indices += item_store[label][:600]
        train_indices += item_store[label][600:]
    
    np.save('./datasets/random_600_test_indices.npy', test_indices)
    np.save('./datasets/random_400_train_indices.npy', train_indices)


def select_examples(opt, num=10):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=1, num_workers=0, shuffle=True)

    # init files
    if not os.path.exists(opt.save_root):
        os.makedirs(opt.save_root)

    # select
    for data_id, data in enumerate(tqdm(test_loader)):
        label_id = data[0].item()
        image = data[1].data.numpy()[0]
        image = np.transpose(image, (1,2,0))
        # store
        label = test_dataset.get_label(label_id)
        img_name = '{}_{}'.format(data_id, label)
        imsave(os.path.join(opt.save_root, opt.save_file.format(img_name)), image)
        if data_id >= num:
            break

def get_info(opt):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=1, num_workers=0, shuffle=False)

    # evaluation
    results = {}
    with torch.no_grad():
        for data in tqdm(test_loader):
            # set to gpu
            labels = data[0].item()
            images = data[1]

            # forward
            if labels not in results:
                results[labels] = 0
            results[labels] += 1

        # display results
        print(results)
        
def test_tsne(opt):
    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    # test_dataset = CifarLoader(opt.root, opt.img_size, train=True)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    # test_dataset = combine_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # define model
    model = get_cls(cls_num=opt.class_num, model=opt.model)
    # model = Resnet_AutoEncoder(model_type=opt.model)
    load_file = os.path.join(opt.save_root, opt.model_file)
    save_dict = torch.load(load_file)
    model.load_state_dict(save_dict['model'])
    if not opt.no_gpu:
        model = model.cuda()

    # evaluation
    results = {}
    model.eval()
    with torch.no_grad():
        for data in tqdm(test_loader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits, features = model(images, get_feature=True)
            features = features.data.cpu().numpy()

            # store
            for l_id, l in enumerate(labels.data.cpu().numpy()):
                if l not in results:
                    results[l] = []
                results[l].append(features[l_id])
    
    # get tsne
    res = []
    for l in results:
        res += results[l]
    res = np.asarray(res)
    X_embedded = TSNE(n_components=2, random_state=0).fit_transform(res)

    # label tsne
    tsne_dict = {}
    cur_len = 0
    for l in results:
        tsne_dict[l] = X_embedded[cur_len:cur_len+len(results[l])]
        cur_len += len(results[l])

    plt.figure()
    for k in tsne_dict:
        plt.plot(tsne_dict[k][:, 0], tsne_dict[k][:, 1], 'o', markersize=5, label=k)

    # plt.legend()
    fig_path = os.path.join(opt.save_root, 'tsne_second_good.pdf')
    plt.xticks([])
    plt.yticks([])
    plt.savefig(fig_path)
    plt.close()

def test_tsne_multi(opt):
    # define model
    model = get_cls(cls_num=opt.class_num, model=opt.model)
    # model = Resnet_AutoEncoder(model_type=opt.model)
    load_file = os.path.join(opt.save_root, opt.model_file)
    save_dict = torch.load(load_file)
    model.load_state_dict(save_dict['model'])
    if not opt.no_gpu:
        model = model.cuda()

    # get files
    sel_files = opt.sel_test_file.split(',')

    # evaluation for each file
    results = {}
    for f_id, _file in enumerate(sel_files):
        results[f_id] = []
        # define dataloader for validation
        test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
        test_dataset = sel_loader(test_dataset, _file)
        test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

        # evaluation
        model.eval()
        with torch.no_grad():
            for data in tqdm(test_loader):
                # set to gpu
                labels = data[0]
                images = data[1]
                if not opt.no_gpu:
                    labels = labels.cuda()
                    images = images.cuda()

                # forward
                logits, features = model(images, get_feature=True)
                features = features.data.cpu().numpy()

                # store
                results[f_id] += list(features)
        
    # get tsne
    res = []
    for l in results:
        res += results[l]
    res = np.asarray(res)
    X_embedded = TSNE(n_components=2, random_state=0).fit_transform(res)

    # label tsne
    tsne_dict = {}
    cur_len = 0
    for l in results:
        tsne_dict[l] = X_embedded[cur_len:cur_len+len(results[l])]
        cur_len += len(results[l])

    plt.figure()
    for k in tsne_dict:
        if k == 0:
            label = 'High Quality'
        elif k == 1:
            label = 'Low QUality'
        plt.plot(tsne_dict[k][:, 0], tsne_dict[k][:, 1], 'o', markersize=5, label=label)

    plt.legend()
    plt.xticks([])
    plt.yticks([])
    fig_path = os.path.join(opt.save_root, 'tsne.pdf')
    plt.savefig(fig_path)
    plt.close()


if __name__ == '__main__':
    opt = get_parser()
    if opt.test_mode == 'acc':
        test(opt)
    elif opt.test_mode == 'find':
        find_specific(opt)
    elif opt.test_mode == 'random_test':
        find_fix_test(opt)
    elif opt.test_mode == 'example':
        # select_examples(opt)
        get_info(opt)
    elif opt.test_mode == 'tsne':
        test_tsne(opt)
    elif opt.test_mode == 'tsne_multi':
        test_tsne_multi(opt)