import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]

import torch
import torch.nn as nn
import torch.nn.functional as F
from model.getcls import get_cls

import pdb

class upsample_layer(nn.Module):
    def __init__(self, in_plane, out_plane, last=False):
        super(upsample_layer, self).__init__()
        # self.upsample = nn.MaxUnpool2d(3, 2)
        self.conv1 = nn.Sequential(nn.Conv2d(in_plane, in_plane, kernel_size=3, stride=1, padding=1),
                                   nn.BatchNorm2d(in_plane, momentum=0.01),
                                   nn.LeakyReLU(0.2))
        self.conv2 = nn.Sequential(nn.Conv2d(in_plane, in_plane, kernel_size=3, stride=1, padding=1),
                                   nn.BatchNorm2d(in_plane, momentum=0.01),
                                   nn.LeakyReLU(0.2))
        self.conv3 = nn.Sequential(nn.ConvTranspose2d(in_plane, out_plane, kernel_size=3, stride=2, padding=0),
                            nn.BatchNorm2d(out_plane, momentum=0.01))
        if last:
            self.nonlinear = nn.Tanh()
        else:
            self.nonlinear = nn.LeakyReLU(0.2)
    
    def forward(self, x):
        # x = self.upsample(x)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.nonlinear(x)
        return x


class Resnet_AutoEncoder(nn.Module):
    def __init__(self, model_type):
        super(Resnet_AutoEncoder, self).__init__()
        # define encoder
        resnet = get_cls(model=model_type)
        resnet = list(resnet.children())[:-2]
        self.encoder = nn.Sequential(*resnet)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        self.en_fc_layer1 = nn.Sequential(nn.Linear(2048, 1024), nn.BatchNorm1d(1024, momentum=0.01), nn.ReLU(inplace=True))
        self.en_fc_layer2 = nn.Sequential(nn.Linear(1024, 768), nn.BatchNorm1d(768, momentum=0.01), nn.ReLU(inplace=True))
        self.en_fc3 = nn.Linear(768, 256)

        # define decoder
        self.de_fc_layer1 = nn.Sequential(nn.Linear(256, 768), nn.BatchNorm1d(768, momentum=0.01), nn.ReLU(inplace=True))
        self.de_fc_layer2 = nn.Sequential(nn.Linear(768, 1024), nn.BatchNorm1d(1024, momentum=0.01), nn.ReLU(inplace=True))

        # self.conv1 = nn.Sequential(nn.Conv2d(2048, 512, kernel_size=3, stride=1, padding=1),
        #                            nn.BatchNorm2d(512),
        #                            nn.LeakyReLU(0.2))
        # self.conv2 = nn.Sequential(nn.Conv2d(512, 256, kernel_size=3, stride=1, padding=1),
        #                            nn.BatchNorm2d(256),
        #                            nn.LeakyReLU(0.2))
        # self.conv3 = nn.Sequential(nn.Conv2d(256, 128, kernel_size=3, stride=1, padding=1),
        #                            nn.BatchNorm2d(128),
        #                            nn.LeakyReLU(0.2))
        # self.conv4 = nn.Sequential(nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1),
        #                            nn.BatchNorm2d(64),
        #                            nn.LeakyReLU(0.2))
        self.up_sample1 = upsample_layer(64, 32)
        self.up_sample2 = upsample_layer(32, 8)
        self.up_sample3 = upsample_layer(8, 3)
    
    def loss_fun(self, raw, recons):
        loss = F.mse_loss(recons, raw)
        return loss

    def encode(self, x):
        x = self.encoder(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.en_fc_layer1(x)
        x = self.en_fc_layer2(x)
        x = self.en_fc3(x)
        return x

    def decode(self, z):
        z = self.de_fc_layer1(z)
        z = self.de_fc_layer2(z)
        z = z.view(-1, 64, 4, 4)
        z = self.up_sample1(z)
        z = self.up_sample2(z)
        z = self.up_sample3(z)
        return z

    def forward(self, raw, get_feature=False):
        # encode
        x = self.encode(raw)
        if get_feature:
            feature = self.avgpool(x).clone()
            feature = torch.flatten(feature, start_dim=1)

        # decodoe
        x = self.decode(x)
        x = F.interpolate(x, size=(32, 32), mode='bilinear')

        # get loss
        loss = self.loss_fun(raw, x)
        if get_feature:
            return loss, feature
        return loss, x