import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]

from .resnet import resnet101, resnet50, resnet34, resnet18
import torch.nn as nn

def get_cls(cls_num=1000, model='resnet', pretrain=True):
    if model == 'resnet101':
        clas = resnet101(pretrained=pretrain)
    elif model == 'resnet50':
        clas = resnet50(pretrained=pretrain)
    elif model == 'resnet18':
        clas = resnet18(pretrained=pretrain)
    fc_in_channel = clas.fc.weight.shape[1]
    clas.fc = nn.Linear(fc_in_channel, cls_num)

    return clas