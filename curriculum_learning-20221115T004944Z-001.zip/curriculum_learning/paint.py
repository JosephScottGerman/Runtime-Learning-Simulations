import matplotlib.pyplot as plt
import numpy as np

def data_size():
    size = [25,50,75,100,125,150,175,200]
    
    # good = [46.78, 60.63,63.12,67.5,73.94,72.16,74.09,76.36]
    # random = [40.8,55.48,63.05,64.59,71.47,71.4,75.37,74.6]
    # bad = [24.23,34.32,39.23,46.34,51.48,56.24,56.84,58.46]

    # good = [48.9,62.67,65.06,72.66,74.75,72.61,74.7,76.32]
    # random = [42.05,57.52,64.74,67.1,72.87,71.98,75.47,74.11]
    # bad = [23.65,35.29,38.95,46.34,51.96,56.53,57,58.61]

    good = [49.03,58.76,64.82,70.83,69.28,70.5,71.37,70.83]
    random = [40.23,54.05,61.6,63.53,69.01,68.58,72,70.22]
    bad = [30.12,41.77,48.47,51.91,60.62,58.58,62.06,66.3]
    ratio = np.asarray(good) / np.asarray(random)

    plt.figure()
    plt.plot(size, good, 'o-', label='good')
    plt.plot(size, random, 'o-', label='random')
    plt.plot(size, bad, 'o-', label='bad')
    plt.legend()
    # plt.xlabel('size per category')
    # plt.ylabel('classification accuracy')
    plt.savefig('results/cls.pdf')
    plt.close()

    plt.figure()
    plt.plot(size, ratio, 'o-')
    # plt.xlabel('size per category')
    # plt.ylabel('classification accuracy ratio')
    plt.savefig('results/cls_ratio.pdf')
    plt.close()

    # good_auto = [42.26,60.31,68.53,67.4,68.9,73.98,74.87,73.38]
    # random_auto = [39.03,46.89,57.76,60.85,63.5,65.56,67.83,69.68]
    # bad_auto = [16.81,25.17,39.23,32.45,51.48,47.89,56.84,58.46]
       
    # plt.figure()
    # plt.plot(size, good_auto, 'o-', label='good')
    # plt.plot(size, random_auto, 'o-', label='random')
    # plt.plot(size, bad_auto, 'o-', label='bad')
    # plt.legend()
    # plt.xlabel('size per category')
    # plt.ylabel('classification accuracy')
    # plt.savefig('results/auto.png')
    # plt.close()

if __name__ == '__main__':
    data_size()