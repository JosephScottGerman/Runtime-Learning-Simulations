import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]
if '/home/cxu-serve/u1/gcui2/code/distillation' not in sys.path:
    sys.path.insert(0, '/home/cxu-serve/u1/gcui2/code/distillation')

from dataloader.imgnet_loader import ImgnetLoader
from dataloader.define_loader import sel_loader
from utils.logs import Logs
from option.base_option import get_parser
from utils.optim import decay_step

import numpy as np
import torch
import torch.utils.data as Data
from tqdm import tqdm

import pdb

def train(opt):
    # define dataloader
    dataset = ImgnetLoader(opt.root, opt.csv_root, opt.img_size, train=True, ratio=opt.auto_ratio)
    dataloader = Data.DataLoader(dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=True)

    # define dataloader for validation
    test_dataset = ImgnetLoader(opt.root, opt.csv_root, opt.img_size, train=False, ratio=opt.auto_ratio)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # Logs
    logger = Logs(opt)

    # define model
    model, optim, cur_epoch = logger.define_autoencoder()

    # do train
    for epoch in tqdm(range(cur_epoch+1, opt.epoches)):
        if epoch != 0 and epoch % opt.epoch_decay == 0:
            decay_step(optim, opt.lr_decay)

        # train
        losses = []
        train_display_results = []
        model.train()
        for step, data in enumerate(tqdm(dataloader)):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            loss, train_result = model(images)
            loss = loss.mean()

            if len(train_display_results) <= 10:
                for i in range(0, min(10, train_result.shape[0])):
                    train_display_results.append([images[i].detach().data.cpu().numpy().transpose(1,2,0), \
                                            train_result[i].detach().data.cpu().numpy().transpose(1,2,0)])

            # backward
            optim.zero_grad()
            loss.backward()
            optim.step()

            # store
            losses.append(loss.detach().data.cpu().item())
            if (step+1) % 10 == 0:
                print('train loss:{}'.format(np.mean(losses)))

        # evaluation
        test_display_results = []
        results = {'test_loss':[], 'losses':losses}
        model.eval()
        with torch.no_grad():
            for data in tqdm(test_loader):
                # set to gpu
                labels = data[0]
                images = data[1]
                if not opt.no_gpu:
                    labels = labels.cuda()
                    images = images.cuda()

                # forward
                loss, test_result = model(images)
                if len(test_display_results) <= 10:
                    for i in range(0, min(10, test_result.shape[0])):
                        test_display_results.append([images[i].cpu().numpy().transpose(1,2,0), \
                                                test_result[i].cpu().numpy().transpose(1,2,0)])
                
                # store
                results['test_loss'].append(loss.detach().data.cpu().numpy())

            # display results
            results['train_display'] = train_display_results
            results['test_display'] = test_display_results
            logger.display_autoencoder_results(epoch, results, optim)
            logger.save_results(model, optim, epoch)

if __name__ == '__main__':
    opt = get_parser()
    train(opt)