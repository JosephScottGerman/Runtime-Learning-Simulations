import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]
if '/home/cxu-serve/u1/gcui2/code/distillation' not in sys.path:
    sys.path.insert(0, '/home/cxu-serve/u1/gcui2/code/distillation')

from dataloader.cifar_loader import CifarLoader
from dataloader.define_loader import sel_loader, combine_loader
from utils.logs import Logs
from option.base_option import get_parser
from utils.optim import decay_step

import torch
import torch.utils.data as Data
from tqdm import tqdm

import pdb

def train_together(opt):
    # define dataloader
    dataset = CifarLoader(opt.root, opt.img_size, train=True, train_with_test=opt.train_with_test)
    # load together
    dataset = combine_loader(dataset, opt.sel_train_file)
    dataloader = Data.DataLoader(dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=True)

    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # Logs
    logger = Logs(opt)

    # define model
    model, optim, cur_epoch = logger.define_model()

    # define loss
    loss_fun = torch.nn.CrossEntropyLoss()

    # initial evaluation
    results = {'preds':[], 'labels':[], 'losses':[0]}
    model.eval()
    with torch.no_grad():
        for data in tqdm(test_loader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            preds = torch.argmax(logits, dim=1)
            
            # store
            results['preds'].append(preds.data.cpu().numpy())
            results['labels'].append(labels.data.cpu().numpy())
        
        logger.display_results(0, results, optim)

    # do train
    for epoch in tqdm(range(cur_epoch+1, opt.epoches)):
        if epoch != 0 and epoch % opt.epoch_decay == 0:
            decay_step(optim, opt.lr_decay)

        # train
        losses = []
        model.train()
        for data in tqdm(dataloader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            loss = loss_fun(logits, labels)

            # backward
            optim.zero_grad()
            loss.backward()
            optim.step()

            # store
            losses.append(loss.detach().cpu().item())

        # evaluation
        results = {'preds':[], 'labels':[], 'losses':losses}
        model.eval()
        with torch.no_grad():
            for data in tqdm(test_loader):
                # set to gpu
                labels = data[0]
                images = data[1]
                if not opt.no_gpu:
                    labels = labels.cuda()
                    images = images.cuda()

                # forward
                logits = model(images)
                preds = torch.argmax(logits, dim=1)
                
                # store
                results['preds'].append(preds.data.cpu().numpy())
                results['labels'].append(labels.data.cpu().numpy())

            # display results
            logger.display_results(epoch, results, optim)
            logger.save_results(model, optim, epoch)

def train_curr(opt):
    # check step
    assert opt.good_step < opt.epoches

    # define dataloader
    dataset = CifarLoader(opt.root, opt.img_size, train=True, train_with_test=opt.train_with_test)
    # load together
    dataset = combine_loader(dataset, opt.sel_train_file)
    dataloader = Data.DataLoader(dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=True)

    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # Logs
    logger = Logs(opt)

    # define model
    model, optim, cur_epoch = logger.define_model()

    # define loss
    loss_fun = torch.nn.CrossEntropyLoss()

    # do train
    for epoch in tqdm(range(cur_epoch+1, opt.epoches)):
        if epoch != 0 and epoch % opt.epoch_decay == 0:
            decay_step(optim, opt.lr_decay)

        # train
        losses = []
        model.train()
        for data in tqdm(dataloader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            loss = loss_fun(logits, labels)

            # backward
            optim.zero_grad()
            loss.backward()
            optim.step()

            # store
            losses.append(loss.detach().cpu().item())

        # evaluation
        results = {'preds':[], 'labels':[], 'losses':losses}
        model.eval()
        with torch.no_grad():
            for data in tqdm(test_loader):
                # set to gpu
                labels = data[0]
                images = data[1]
                if not opt.no_gpu:
                    labels = labels.cuda()
                    images = images.cuda()

                # forward
                logits = model(images)
                preds = torch.argmax(logits, dim=1)
                
                # store
                results['preds'].append(preds.data.cpu().numpy())
                results['labels'].append(labels.data.cpu().numpy())

            # display results
            logger.display_results(epoch, results, optim)
            logger.save_results(model, optim, epoch)


if __name__ == '__main__':
    opt = get_parser()
    train_together(opt)