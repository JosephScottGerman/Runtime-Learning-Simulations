import argparse

def get_parser():
    parser = argparse.ArgumentParser()

    ###### dataset #########
    parser.add_argument('--root', type=str, help='root directory of data')
    parser.add_argument('--csv_root', type=str, help='root directory of csv file')
    parser.add_argument('--img_size', type=int, default=32, help='size of image')
    parser.add_argument('--sel_train_file', type=str, default=None, help='select dataset with specific file')
    parser.add_argument('--sel_test_file', type=str, default=None, help='select dataset with specific file')
    parser.add_argument('--auto_ratio', type=float, default=0.01, help='ratio of data used for autoencoder')

    ###### model #########
    parser.add_argument('--model', type=str, default='resnet', help='model (resnet)')
    parser.add_argument('--class_num', type=int, default=10, help='number of categories')

    ###### train #########
    parser.add_argument('--no_gpu', action='store_true', help='if specific, no gpu used')
    parser.add_argument('--load_pretrain', action='store_true', help='if specific, load pretrained parameters')
    parser.add_argument('--load_from_auto', action='store_true', help='if specific, load parameters from autoencoder')
    parser.add_argument('--only_weight', action='store_true', help='if specific, only load model weight')
    parser.add_argument('--train_with_test', action='store_true', help='if specific, load test data for train')

    parser.add_argument('--lr', type=float, help='learning rate for training')
    parser.add_argument('--lr_decay', type=float, default=1, help='decay ratio of learning rate for training')
    parser.add_argument('--epoch_decay', type=int, help='decay one time for defined epoch')
    parser.add_argument('--optim', type=str, default='sgd', help='optimizer for training')
    parser.add_argument('--epoches', type=int, help='total epoch for training')
    parser.add_argument('--batch_size', type=int, default=2, help='batch size for training')
    parser.add_argument('--num_worker', type=int, help='number of worker for dataloader')
    parser.add_argument('--sel_num', type=int, default=None, help='if specific, select certain number for each cls')

    parser.add_argument('--good_step', type=int, default=None, help='training step for good indices during curriculum learning')

    ###### test #########
    parser.add_argument('--test_mode', type=str, default='acc', help='acc/find')
    parser.add_argument('--find_store', type=str, help='path to store good and bad indices')
    parser.add_argument('--find_from_train', action='store_true', help='if specific, find subset from train set')

    ###### Logs #########
    parser.add_argument('--save_root', type=str, help='root directory to save results')
    parser.add_argument('--save_file', type=str, help='name of file to save (store training parameters)')
    parser.add_argument('--model_file', type=str, help='name of file (store training parameters)')
    parser.add_argument('--tfboard_dir', type=str, help='name of directory for tensorboard')
    parser.add_argument('--save_epoch', type=int, default=5, help='save parameter per defined epoch')

    opt = parser.parse_args()

    return opt