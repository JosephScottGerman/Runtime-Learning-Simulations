import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]

import numpy as np
import pandas as pd
import pickle
import copy
import os
from PIL import Image
import cv2
from torchvision import transforms

from dataloader.autoaugmentation import CIFAR10Policy
import pdb

class ImgnetLoader:
    # init
    def __init__(self, root, csv_root, img_size, train=True, ratio=0.01):
        self.root = root
        self.train = train
        # get subset csv
        if self.train:
            csv_file = os.path.join(csv_root, '{}_subset.csv'.format(ratio))
            if not os.path.exists(csv_file):
                csv_d = self.create_subset(csv_root, ratio)
                csv_d.to_csv(csv_file, index=False)
            else:
                csv_d = pd.read_csv(csv_file)
        else:
            ratio = 0.1
            csv_file = os.path.join(csv_root, '{}_subset_test.csv'.format(ratio))
            if not os.path.exists(csv_file):
                csv_d = self.create_subset(csv_root, ratio)
                csv_d.to_csv(csv_file, index=False)
            else:
                csv_d = pd.read_csv(csv_file)

        # other store
        self.csv_d = csv_d
        self.img_size = img_size
        self.transform = self.get_transform()

    # length
    def __len__(self):
        return len(self.csv_d)

    # get item
    def __getitem__(self, index):
        img_path = self.csv_d['path'][index]
        label = self.csv_d['label'][index]

        img = self.get_img(os.path.join(self.root, img_path))

        return label, img

    # get image
    def get_img(self, img_path):
        img = cv2.imread(img_path)
        if img.shape[2] == 1:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        return self.transform(Image.fromarray(img))

    # transformer
    def get_transform(self, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):
        if self.train:
            t = [transforms.Resize((self.img_size, self.img_size)),
                transforms.RandomCrop((self.img_size, self.img_size), padding=4),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)]
        else:
            t = [transforms.Resize((self.img_size, self.img_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)]

        return transforms.Compose(t)

    # create subset
    def create_subset(self, csv_root, ratio):
        # origin csv
        csv_file = os.path.join(csv_root, 'origin.csv')
        assert os.path.exists(csv_file)
        # load
        csv_d = pd.read_csv(csv_file)
        if self.train:
            csv_d = csv_d[csv_d['is_train']==1]
        else:
            csv_d = csv_d[csv_d['is_train']==0]
        
        # select subset
        new_csv_d = []
        for cls_num in range(1000):
            sub_d = csv_d[csv_d['label']==cls_num]
            sub_d = sub_d.sample(frac=ratio).reset_index(drop=True)
            new_csv_d.append(sub_d)
        new_csv_d = pd.concat(new_csv_d, ignore_index=True, sort=False).reset_index(drop=True)
        
        return new_csv_d
