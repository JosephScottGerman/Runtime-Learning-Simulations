import os
import numpy as np

import pdb

def sel_loader(dataset, sel_file, nums=None):
    if sel_file is not None and os.path.exists(sel_file):
        print('sel file: {}'.format(sel_file))
        if nums is not None:
            print('reselect {} datas per category'.format(nums))
        dataset.reselect(ids=sel_file, file=True, nums=nums)
    else:
        print('no sel file')
    return dataset

def combine_loader(dataset, sel_files):
    files = sel_files.split(',')
    ids = [np.load(f) for f in files]
    ids = np.concatenate(ids, axis=0)
    print('loaded total len {}'.format(ids.shape[0]))
    print('files are {}'.format(files))
    dataset.reselect(ids=ids, file=False)
    return dataset