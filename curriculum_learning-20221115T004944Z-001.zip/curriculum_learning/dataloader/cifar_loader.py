import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]

import numpy as np
import pickle
import copy
import os
from PIL import Image
from torchvision import transforms

from dataloader.autoaugmentation import CIFAR10Policy
import pdb

test_datafiles = ['test_batch']
datafiles = ['data_batch_1', 'data_batch_2', 'data_batch_3', 'data_batch_4', 'data_batch_5']
# datafiles = ['data_batch_1']
keys = [b'batch_label', b'labels', b'data', b'filenames']
label_list = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

class CifarLoader:
    # init
    def __init__(self, root, img_size, train=True, train_with_test=False):
        # load cifar dataset
        self.dataset = {}
        if train and not train_with_test:
            print('train with train dataset')
            loadfile = datafiles
        else:
            print('train with test dataset')
            loadfile = test_datafiles
        for f in loadfile:
            with open(os.path.join(root,f), 'rb') as file:
                new_data = pickle.load(file, encoding='bytes')
                if keys[0] not in self.dataset:
                    self.dataset = new_data
                    self.dataset[b'batch_label'] = [self.dataset[b'batch_label']]
                else:
                    self.dataset[b'batch_label'] += new_data[b'batch_label']
                    self.dataset[b'labels'] += new_data[b'labels']
                    self.dataset[b'data'] = np.concatenate([self.dataset[b'data'], new_data[b'data']], axis=0)
                    self.dataset[b'filenames'] += new_data[b'filenames']
                        
        # store parameter
        self.sel_ids = None
        self.data = copy.deepcopy(self.dataset)
        self.train = train
        self.img_size = img_size
        self.transform = self.get_transform()

    # choose
    def reselect(self, ids, file=True, nums=None):
        # load index    
        if file:
            ids = np.load(ids)
            if nums is not None:
                # gather category
                cat_ids = {}
                for i in ids:
                    cat = self.dataset[b'labels'][i]
                    if cat not in cat_ids:
                        cat_ids[cat] = []
                    cat_ids[cat].append(i)
                # random select
                new_ids = []
                for cat in cat_ids:
                    # np.random.shuffle(cat_ids[cat])
                    new_ids += cat_ids[cat][:nums]
                ids = new_ids
        
        self.sel_ids = ids
        for key in keys[1:]:
            self.data[key] = np.asarray(self.dataset[key])[ids]

    # get data
    def __getitem__(self, index):
        label = self.data[b'labels'][index]
        image = self.data[b'data'][index].reshape(3,32,32)
        image = np.transpose(image, (1,2,0))

        image = self.transform(Image.fromarray(image))
        
        return label, image

    # length
    def __len__(self):
        return self.data[b'data'].shape[0]

    # get label
    def get_label(self, label_id):
        return label_list[label_id]

    # get selected ids
    def get_sel_ids(self, index):
        if self.sel_ids is None:
            return index
        return self.sel_ids[index]

    # transform
    def get_transform(self, mean=[0.4914, 0.4822, 0.4465], std=[0.2023, 0.1994, 0.2010]):
        if self.train:
            t = [transforms.RandomCrop((self.img_size, self.img_size), padding=4),
                transforms.RandomHorizontalFlip(),
                CIFAR10Policy(fillcolor=(128,128,128)),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)]
        else:
            t = [transforms.Resize((self.img_size, self.img_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)]

        return transforms.Compose(t)