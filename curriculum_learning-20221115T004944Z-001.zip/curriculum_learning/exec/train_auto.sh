train(){
    CUDA_VISIBLE_DEVICES=$1 python train_auto.py \
    --root '/home/cxu-serve/p1/gcui2/ILSVRC' \
    --csv_root '/home/cxu-serve/u1/gcui2/code/distillation/datasets/ILSVRC' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 20 \
    --img_size 32 \
    --model 'resnet50' \
    --load_pretrain \
    --lr 1e-1 \
    --lr_decay 0.01 \
    --epoch_decay 100 \
    --epoches 500 \
    --batch_size 120 \
    --num_worker 8 \
    --optim 'adam' \
    --auto_ratio 0.01
}

train 3 'auto_2' 'latest'