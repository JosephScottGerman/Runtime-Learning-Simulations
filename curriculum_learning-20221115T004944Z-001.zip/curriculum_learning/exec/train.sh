train(){
    CUDA_VISIBLE_DEVICES=$1 python train.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 200 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-1 \
    --lr_decay 0.1 \
    --epoch_decay 500 \
    --epoches 1500 \
    --batch_size 750 \
    --num_worker 8 \
    --optim 'sgd' \
    --only_weight \
    --load_from_auto
}

train_with_sel(){
    CUDA_VISIBLE_DEVICES=$1 python train.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 200 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-2 \
    --lr_decay 0.1 \
    --epoch_decay 800 \
    --epoches 1850 \
    --batch_size 250 \
    --num_worker 8 \
    --optim 'adam' \
    --sel_train_file 'datasets/'$4 \
    --sel_test_file 'datasets/random_600_test_indices.npy' \
    --train_with_test
    # --only_weight
}

train_with_random_sel(){
    CUDA_VISIBLE_DEVICES=$1 python train.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 600 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-2 \
    --lr_decay 0.1 \
    --epoch_decay 800 \
    --epoches 1850 \
    --batch_size 250 \
    --num_worker 4 \
    --optim 'adam' \
    --sel_train_file 'datasets/'$4 \
    --sel_test_file 'datasets/random_600_test_indices.npy' \
    --sel_num 150 \
    --only_weight
}

train_with_level(){
    CUDA_VISIBLE_DEVICES=$1 python train_level.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 200 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-2 \
    --lr_decay 0.1 \
    --epoch_decay 800 \
    --epoches 1850 \
    --batch_size 250 \
    --num_worker 8 \
    --optim 'adam' \
    --sel_train_file 'datasets/find_equal_75_good_indices.npy,datasets/find_equal_75_bad_indices.npy' \
    --sel_test_file 'datasets/find_equal_150_test_indices.npy' \
    --train_with_test
}

train_with_auto(){
    CUDA_VISIBLE_DEVICES=$1 python train.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 200 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-2 \
    --lr_decay 0.1 \
    --epoch_decay 800 \
    --epoches 1850 \
    --batch_size 250 \
    --num_worker 8 \
    --optim 'adam' \
    --sel_train_file 'datasets/'$4 \
    --sel_test_file 'datasets/find_auto_equal_100_test_indices.npy' \
    --only_weight \
    --load_from_auto \
    --train_with_test
}

train_with_auto_random(){
    CUDA_VISIBLE_DEVICES=$1 python train.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --tfboard_dir 'tensorboard' \
    --save_epoch 200 \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --lr 1e-2 \
    --lr_decay 0.1 \
    --epoch_decay 800 \
    --epoches 1850 \
    --batch_size 250 \
    --num_worker 8 \
    --optim 'adam' \
    --sel_train_file 'datasets/'$4 \
    --sel_test_file 'datasets/find_auto_equal_200_test_indices.npy' \
    --only_weight \
    --load_from_auto \
    --sel_num 200
}

# train 1,2,3 'full_train_auto' 'auto'
train_with_sel 3 'level_150_new' 'latest' 'find_new_equal_150_level_indices.npy'
# train_with_random_sel 3 'level_150_random' 'latest' 'random_two.npy'
# train_with_level 3 'good_bad_sel' 'latest'
# train_with_auto 3 'bad_sel_equal_auto_100' 'auto' 'find_auto_equal_100_bad_indices.npy'
# train_with_auto_random 1 'random_sel_equal_auto_200' 'auto' 'random_two.npy'