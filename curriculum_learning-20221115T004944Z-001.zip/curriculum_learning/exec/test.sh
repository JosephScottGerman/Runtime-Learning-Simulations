test_with_sel(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --batch_size 48 \
    --num_worker 4 \
    --optim 'sgd' \
    --sel_test_file 'datasets/random_600_test_indices.npy'
}

test_with_sel_good(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --batch_size 48 \
    --num_worker 4 \
    --optim 'sgd' \
    --sel_test_file 'datasets/eval_50_good_indices.npy'
}

test_with_sel_tsne(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --batch_size 48 \
    --num_worker 4 \
    --optim 'sgd' \
    --test_mode $4 \
    --sel_test_file $5
}

test_and_find(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --batch_size 48 \
    --num_worker 0 \
    --optim 'sgd' \
    --test_mode 'find' \
    --find_store 'datasets/find_new_equal_75_random_{}_indices.npy' \
    --sel_test_file 'datasets/random_two.npy' \
    --find_from_train \
    --sel_num 150
}

test_and_find_eval(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/'$2 \
    --save_file 'latest_epoch.pth' \
    --model_file $3'_epoch.pth' \
    --img_size 32 \
    --model 'resnet50' \
    --class_num 10 \
    --load_pretrain \
    --batch_size 48 \
    --num_worker 0 \
    --optim 'sgd' \
    --test_mode 'find' \
    --find_store 'datasets/eval_50_{}_indices.npy' \
    --sel_test_file 'datasets/random_600_test_indices.npy'
    # --find_from_train
}

test_random_find(){
    CUDA_VISIBLE_DEVICES=$1 python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --img_size 32 \
    --class_num 10 \
    --num_worker 0 \
    --test_mode 'random_test'
}

test_select_images(){
    python test.py \
    --root '/home/cxu-serve/p1/gcui2/cifar10' \
    --save_root 'experiment/example_images' \
    --save_file $1'{}_.png' \
    --img_size 32 \
    --test_mode 'example' \
    --train_with_test \
    --sel_test_file $2
}

# test_random_find 3
test_with_sel 3 'level_150_new_good_first_better_bad/800_start' latest
# test_with_sel_good 3 'new_good_sel_equal_find_200' latest
# test_with_sel_tsne 3 'random_sel_preprocess_75_0' latest 'tsne' 'datasets/find_second_equal_75_good_indices.npy'
# test_and_find 0 'full_train' 'latest'
# test_and_find_eval 3 'full_train' 'latest'
# test_select_images 'good' 'datasets/find_auto_good_indices.npy'