import sys
if '/home/cxu-serve/u1/gcui2/code/AE-WTN' in sys.path:
    sys.path = sys.path[:-2]
if '/home/cxu-serve/u1/gcui2/code/distillation' not in sys.path:
    sys.path.insert(0, '/home/cxu-serve/u1/gcui2/code/distillation')

from dataloader.cifar_loader import CifarLoader
from dataloader.define_loader import sel_loader
from utils.logs import Logs
from option.base_option import get_parser
from utils.optim import decay_step

import torch
import torch.utils.data as Data
from tqdm import tqdm

import pdb

def train(opt):
    # define dataloader
    dataset = CifarLoader(opt.root, opt.img_size, train=True, train_with_test=opt.train_with_test)
    dataset = sel_loader(dataset, opt.sel_train_file, opt.sel_num)
    dataloader = Data.DataLoader(dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=True)

    # define dataloader for validation
    test_dataset = CifarLoader(opt.root, opt.img_size, train=False)
    test_dataset = sel_loader(test_dataset, opt.sel_test_file)
    test_loader = Data.DataLoader(test_dataset, batch_size=opt.batch_size, num_workers=opt.num_worker, shuffle=False)

    # Logs
    logger = Logs(opt)

    # define model
    model, optim, cur_epoch = logger.define_model()

    # define loss
    loss_fun = torch.nn.CrossEntropyLoss()

    # do train
    epoch_decay = opt.epoch_decay
    for epoch in tqdm(range(cur_epoch+1, opt.epoches)):
        if epoch != 0 and epoch % epoch_decay == 0:
            decay_step(optim, opt.lr_decay)
            # epoch_decay = int(epoch_decay / 2)

        # train
        losses = []
        model.train()
        for data in tqdm(dataloader):
            # set to gpu
            labels = data[0]
            images = data[1]
            if not opt.no_gpu:
                labels = labels.cuda()
                images = images.cuda()

            # forward
            logits = model(images)
            loss = loss_fun(logits, labels)

            # backward
            optim.zero_grad()
            loss.backward()
            optim.step()

            # store
            losses.append(loss.detach().cpu().item())

        # evaluation
        results = {'preds':[], 'labels':[], 'losses':losses}
        model.eval()
        with torch.no_grad():
            for data in tqdm(test_loader):
                # set to gpu
                labels = data[0]
                images = data[1]
                if not opt.no_gpu:
                    labels = labels.cuda()
                    images = images.cuda()

                # forward
                logits = model(images)
                preds = torch.argmax(logits, dim=1)
                
                # store
                results['preds'].append(preds.data.cpu().numpy())
                results['labels'].append(labels.data.cpu().numpy())

            # display results
            logger.display_results(epoch, results, optim)
            logger.save_results(model, optim, epoch)

if __name__ == '__main__':
    opt = get_parser()
    train(opt)